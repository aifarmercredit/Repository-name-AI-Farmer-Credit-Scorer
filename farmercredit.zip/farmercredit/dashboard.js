const accountName = document.getElementById("accountName");
const accountEmail = document.getElementById("accountEmail");
const farmerName = document.getElementById("farmerName");
const avatar = document.getElementById("avatar");
const accountButton = document.getElementById("accountButton");
const accountDropdown = document.getElementById("accountDropdown");
const assessmentForm = document.getElementById("assessmentForm");
const resultCard = document.getElementById("resultCard");
const livePreview = document.getElementById("livePreview");
const livePreviewScore = document.getElementById("livePreviewScore");

document.getElementById("today").textContent = new Intl.DateTimeFormat("en-KE", { weekday: "long", day: "numeric", month: "long" }).format(new Date());

async function request(path, options) {
  const response = await fetch(path, { credentials: "same-origin", ...options });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}

async function loadAccount() {
  try {
    const { user } = await request("/api/auth/session");
    const firstName = (user.fullName || "Farmer").split(" ")[0];
    accountName.textContent = user.fullName || "Farmer";
    accountEmail.textContent = user.email;
    farmerName.textContent = firstName;
    avatar.textContent = firstName.charAt(0).toUpperCase();
  } catch { window.location.replace("auth.html?mode=signin"); }
}

accountButton.addEventListener("click", () => {
  const open = accountDropdown.classList.toggle("open");
  accountButton.setAttribute("aria-expanded", String(open));
});
document.addEventListener("click", (event) => { if (!event.target.closest(".account-menu")) accountDropdown.classList.remove("open"); });
document.getElementById("signOut").addEventListener("click", async () => {
  await request("/api/auth/signout", { method: "POST" });
  window.location.replace("index.html");
});

function scrollToSection(id) { document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" }); }
document.querySelectorAll("[data-scroll]").forEach((button) => button.addEventListener("click", () => scrollToSection(button.dataset.scroll)));
document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.remove("active"));
  button.classList.add("active");
  scrollToSection(button.dataset.target);
  closeSidebar();
}));

const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("sidebarOverlay");
function closeSidebar() { sidebar.classList.remove("open"); overlay.classList.remove("open"); }
document.getElementById("menuButton").addEventListener("click", () => { sidebar.classList.add("open"); overlay.classList.add("open"); });
overlay.addEventListener("click", closeSidebar);

function calculateScore() {
  const acres = Number(document.getElementById("farmSize").value);
  const years = Number(document.getElementById("yearsFarming").value);
  const income = Number(document.getElementById("monthlyIncome").value);
  const loan = Number(document.getElementById("loanBalance").value);
  const history = document.getElementById("repaymentHistory").value;
  let score = 35;
  score += Math.min(acres * 1.5, 12) + Math.min(years * 2, 15) + Math.min(income / 5000, 18);
  score += ({ good: 20, fair: 10, new: 12, poor: 0 })[history] || 0;
  if (income > 0) score -= Math.min((loan / (income * 12)) * 12, 18);
  return Math.max(20, Math.min(95, Math.round(score)));
}

function formHasEnoughData() {
  return document.getElementById("farmSize").value && document.getElementById("monthlyIncome").value;
}

/* Live running estimate as the farmer fills the form, before submitting */
["farmSize", "yearsFarming", "monthlyIncome", "loanBalance", "repaymentHistory"].forEach((id) => {
  document.getElementById(id).addEventListener("input", () => {
    if (formHasEnoughData()) {
      livePreview.hidden = false;
      livePreviewScore.textContent = `${calculateScore()} / 100`;
    } else {
      livePreview.hidden = true;
    }
  });
});

assessmentForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const score = calculateScore();
  const title = score >= 75 ? "Strong readiness" : score >= 55 ? "Developing readiness" : "Needs improvement";
  const message = score >= 75
    ? "Your farming experience, cash flow and repayment profile indicate good lending readiness."
    : score >= 55
    ? "You have a useful foundation. Better records and lower debt can strengthen your next application."
    : "Focus on reliable farm records, steady income and timely repayments before applying for a larger loan.";

  animateScore(score);
  document.getElementById("resultTitle").textContent = title;
  document.getElementById("resultMessage").textContent = message;
  document.getElementById("summaryScore").textContent = `${score} / 100`;
  document.getElementById("scoreHint").textContent = title;
  document.getElementById("profileStatus").textContent = "Assessment complete";
  document.getElementById("assessmentCount").textContent = "1 completed";
  assessmentForm.style.display = "none";
  resultCard.classList.add("show");
  resultCard.scrollIntoView({ behavior: "smooth", block: "center" });
});

function animateScore(target) {
  const resultScore = document.getElementById("resultScore");
  const scoreRing = document.getElementById("scoreRing");
  const duration = 700;
  const start = performance.now();
  function frame(now) {
    const progress = Math.min((now - start) / duration, 1);
    const value = Math.round(target * (1 - Math.pow(1 - progress, 3)));
    resultScore.textContent = value;
    scoreRing.style.background = `conic-gradient(var(--leaf) ${value}%, #e2d8b8 ${value}%)`;
    if (progress < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}

document.getElementById("recalculate").addEventListener("click", () => {
  resultCard.classList.remove("show");
  assessmentForm.style.display = "block";
});

loadAccount();
