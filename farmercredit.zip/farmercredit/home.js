const header = document.getElementById("siteHeader");
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

window.addEventListener("scroll", () => header.classList.toggle("scrolled", window.scrollY > 20), { passive: true });

menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.innerHTML = `<i class="fa-solid fa-${open ? "xmark" : "bars"}"></i>`;
});
document.querySelectorAll(".nav-links a").forEach((link) => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
}));

const sections = [...document.querySelectorAll("main section[id]")];
window.addEventListener("scroll", () => {
  const current = sections.filter((section) => section.offsetTop <= window.scrollY + 140).pop();
  document.querySelectorAll(".nav-links a[href^='#']").forEach((link) => link.classList.toggle("active", current && link.getAttribute("href") === `#${current.id}`));
}, { passive: true });

document.getElementById("contactForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const name = document.getElementById("contactName").value.trim().split(" ")[0];
  document.getElementById("contactStatus").textContent = `Thanks${name ? `, ${name}` : ""}! Your message has been received.`;
  event.target.reset();
});

/* ---- Live "try it now" ledger widget ---- */
const acresRange = document.getElementById("acresRange");
const incomeRange = document.getElementById("incomeRange");
const historyRange = document.getElementById("historyRange");
const acresOut = document.getElementById("acresOut");
const incomeOut = document.getElementById("incomeOut");
const historyOut = document.getElementById("historyOut");
const previewScore = document.getElementById("previewScore");
const previewLabel = document.getElementById("previewLabel");
const historyLabels = ["Often late", "Occasionally late", "No history yet", "Always on time"];
const historyScores = [0, 10, 12, 20];

function updatePreview() {
  const acres = Number(acresRange.value);
  const income = Number(incomeRange.value);
  const historyIndex = Number(historyRange.value);

  acresOut.textContent = `${acres} acre${acres === 1 ? "" : "s"}`;
  incomeOut.textContent = `KSh ${income.toLocaleString()}`;
  historyOut.textContent = historyLabels[historyIndex];

  let score = 35 + Math.min(acres * 1.5, 12) + Math.min(income / 5000, 18) + historyScores[historyIndex];
  score = Math.max(20, Math.min(95, Math.round(score)));
  previewScore.textContent = score;
  previewLabel.textContent = score >= 75 ? "Strong readiness" : score >= 55 ? "Developing readiness" : "Needs improvement";
}
[acresRange, incomeRange, historyRange].forEach((input) => input.addEventListener("input", updatePreview));
updatePreview();
