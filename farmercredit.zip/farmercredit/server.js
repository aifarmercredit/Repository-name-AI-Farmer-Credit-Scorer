/* Local authentication server. Start with: node server.js */
const http = require("http");
const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

const ROOT_DIR = __dirname;
const DATA_DIR = path.join(ROOT_DIR, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const PORT = Number(process.env.PORT || 3000);
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const sessions = new Map();
const googleStates = new Map();
const mimeTypes = { ".css": "text/css; charset=utf-8", ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".svg": "image/svg+xml", ".ico": "image/x-icon", ".mp4": "video/mp4" };

async function ensureUserStore() { await fs.mkdir(DATA_DIR, { recursive: true }); try { await fs.access(USERS_FILE); } catch { await fs.writeFile(USERS_FILE, "[]\n", "utf8"); } }
async function readUsers() { await ensureUserStore(); return JSON.parse(await fs.readFile(USERS_FILE, "utf8")); }
async function saveUsers(users) { await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2) + "\n", "utf8"); }
function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) { return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (error, key) => error ? reject(error) : resolve({ salt, hash: key.toString("hex") }))); }
async function passwordMatches(password, user) { if (!user.passwordHash || !user.passwordSalt) return false; const result = await hashPassword(password, user.passwordSalt); return crypto.timingSafeEqual(Buffer.from(result.hash, "hex"), Buffer.from(user.passwordHash, "hex")); }
function parseCookies(request) { return (request.headers.cookie || "").split(";").reduce((cookies, part) => { const index = part.indexOf("="); if (index > 0) cookies[part.slice(0, index).trim()] = decodeURIComponent(part.slice(index + 1)); return cookies; }, {}); }
function getSession(request) { const token = parseCookies(request).auth_session; const session = token && sessions.get(token); if (!session || session.expiresAt < Date.now()) { if (token) sessions.delete(token); return null; } return session; }
function createSession(response, user) { const token = crypto.randomBytes(32).toString("base64url"); sessions.set(token, { userId: user.id, expiresAt: Date.now() + SESSION_TTL_MS }); response.setHeader("Set-Cookie", `auth_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_TTL_MS / 1000}`); }
function clearSession(request, response) { const token = parseCookies(request).auth_session; if (token) sessions.delete(token); response.setHeader("Set-Cookie", "auth_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0"); }
function publicUser(user) { return { id: user.id, email: user.email, fullName: user.fullName, provider: user.provider }; }
function sendJson(response, status, payload) { response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }); response.end(JSON.stringify(payload)); }
async function readBody(request) { let body = ""; for await (const chunk of request) { body += chunk; if (body.length > 20_000) throw new Error("Request is too large."); } return body ? JSON.parse(body) : {}; }

async function handleApi(request, response, url) {
    if (request.method === "GET" && url.pathname === "/api/auth/session") { const session = getSession(request); if (!session) return sendJson(response, 401, { error: "You are not signed in." }); const user = (await readUsers()).find((entry) => entry.id === session.userId); return user ? sendJson(response, 200, { user: publicUser(user) }) : sendJson(response, 401, { error: "Session is no longer valid." }); }
    if (request.method === "POST" && url.pathname === "/api/auth/signup") {
        const { fullName = "", email = "", password = "" } = await readBody(request); const normalizedEmail = email.trim().toLowerCase();
        if (!fullName.trim()) return sendJson(response, 400, { error: "Please enter your full name." });
        if (!/^\S+@\S+\.\S+$/.test(normalizedEmail)) return sendJson(response, 400, { error: "Please enter a valid email address." });
        if (password.length < 8) return sendJson(response, 400, { error: "Password must be at least 8 characters." });
        const users = await readUsers(); if (users.some((user) => user.email === normalizedEmail)) return sendJson(response, 409, { error: "An account with this email already exists." });
        const credentials = await hashPassword(password); const user = { id: crypto.randomUUID(), email: normalizedEmail, fullName: fullName.trim(), provider: "password", passwordHash: credentials.hash, passwordSalt: credentials.salt, createdAt: new Date().toISOString() };
        users.push(user); await saveUsers(users); createSession(response, user); return sendJson(response, 201, { user: publicUser(user) });
    }
    if (request.method === "POST" && url.pathname === "/api/auth/signin") { const { email = "", password = "" } = await readBody(request); const user = (await readUsers()).find((entry) => entry.email === email.trim().toLowerCase()); if (!user || !(await passwordMatches(password, user))) return sendJson(response, 401, { error: "Incorrect email or password." }); createSession(response, user); return sendJson(response, 200, { user: publicUser(user) }); }
    if (request.method === "POST" && url.pathname === "/api/auth/signout") { clearSession(request, response); return sendJson(response, 200, { ok: true }); }
    if (request.method === "GET" && url.pathname === "/api/auth/google") {
        const clientId = process.env.GOOGLE_CLIENT_ID; const baseUrl = process.env.BASE_URL || `http://localhost:${PORT}`;
        if (!clientId || !process.env.GOOGLE_CLIENT_SECRET) { response.writeHead(302, { Location: "/auth.html?auth_error=Google+sign-in+is+not+configured+yet." }); return response.end(); }
        const state = crypto.randomBytes(24).toString("base64url"); googleStates.set(state, Date.now() + 10 * 60 * 1000);
        const googleUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth"); googleUrl.search = new URLSearchParams({ client_id: clientId, redirect_uri: `${baseUrl}/api/auth/google/callback`, response_type: "code", scope: "openid email profile", state, prompt: "select_account" }); response.writeHead(302, { Location: googleUrl.toString() }); return response.end();
    }
    if (request.method === "GET" && url.pathname === "/api/auth/google/callback") {
        const stateExpiry = googleStates.get(url.searchParams.get("state")); googleStates.delete(url.searchParams.get("state"));
        if (!stateExpiry || stateExpiry < Date.now() || !url.searchParams.get("code")) { response.writeHead(302, { Location: "/auth.html?auth_error=Google+sign-in+could+not+be+verified." }); return response.end(); }
        const baseUrl = process.env.BASE_URL || `http://localhost:${PORT}`;
        const tokenResponse = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams({ code: url.searchParams.get("code"), client_id: process.env.GOOGLE_CLIENT_ID, client_secret: process.env.GOOGLE_CLIENT_SECRET, redirect_uri: `${baseUrl}/api/auth/google/callback`, grant_type: "authorization_code" }) }); const tokens = await tokenResponse.json(); if (!tokenResponse.ok) throw new Error(tokens.error_description || "Google token exchange failed.");
        const profileResponse = await fetch("https://openidconnect.googleapis.com/v1/userinfo", { headers: { Authorization: `Bearer ${tokens.access_token}` } }); const profile = await profileResponse.json(); if (!profileResponse.ok || !profile.email) throw new Error("Google did not return an email address.");
        const users = await readUsers(); let user = users.find((entry) => entry.email === profile.email.toLowerCase()); if (!user) { user = { id: crypto.randomUUID(), email: profile.email.toLowerCase(), fullName: profile.name || profile.email, provider: "google", createdAt: new Date().toISOString() }; users.push(user); await saveUsers(users); } createSession(response, user); response.writeHead(302, { Location: "/dashboard.html" }); return response.end();
    }
    return sendJson(response, 404, { error: "Not found." });
}

async function serveStatic(request, response, url) { const relativePath = url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname).replace(/^\/+/, ""); if (relativePath === "dashboard.html" && !getSession(request)) { response.writeHead(302, { Location: "/auth.html?mode=signin" }); return response.end(); } const filePath = path.resolve(ROOT_DIR, relativePath); if (!filePath.startsWith(ROOT_DIR + path.sep)) { response.writeHead(403); return response.end("Forbidden"); } try { const content = await fs.readFile(filePath); response.writeHead(200, { "Content-Type": mimeTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-store" }); response.end(content); } catch { response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); response.end("Not found"); } }

http.createServer(async (request, response) => { try { const url = new URL(request.url, `http://${request.headers.host}`); if (url.pathname.startsWith("/api/")) return await handleApi(request, response, url); return await serveStatic(request, response, url); } catch (error) { console.error(error); return sendJson(response, 500, { error: "Something went wrong. Please try again." }); } }).listen(PORT, () => console.log(`AI Farmer Credit Scorer is running at http://localhost:${PORT}`));
